package com.example.msgtoothers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
